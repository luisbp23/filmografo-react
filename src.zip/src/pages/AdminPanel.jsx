import { useEffect, useState, useCallback } from 'react';
import { getConteudoPendente, getDenunciasPendentes, aprovar, rejeitar, resolverDenuncia, ignorarDenuncia } from '../services/adminService';
import './AdminPanel.css';

const ABAS = ['Filmes', 'Séries', 'Denúncias'];

function AdminPanel() {
    const [abaAtiva, setAbaAtiva] = useState('Filmes');
    const [filmes, setFilmes] = useState([]);
    const [series, setSeries] = useState([]);
    const [denuncias, setDenuncias] = useState([]);
    const [loading, setLoading] = useState(false);
    
    const carregarDados = useCallback(async () => {
        setLoading(true);
        try {
            if (abaAtiva === 'Filmes') {
                const dados = await getConteudoPendente('movie');
                setFilmes(dados);
            } else if (abaAtiva === 'Séries') {
                const dados = await getConteudoPendente('series');
                setSeries(dados);
            } else if (abaAtiva === 'Denúncias') {
                const dados = await getDenunciasPendentes();
                setDenuncias(dados);
            }
        } finally {
            setLoading(false);
        }
    }, [abaAtiva]);
    
    useEffect(() => {
        carregarDados();
    }, [abaAtiva, carregarDados]);
    
    async function handleAprovar(id) {
        if (!window.confirm('Tem a certeza que quer aprovar este conteúdo?')) return;
        await aprovar(id);
        carregarDados();
    }
    
    async function handleRejeitar(id) {
        if (!window.confirm('Tem a certeza que quer rejeitar este conteúdo?')) return;
        await rejeitar(id);
        carregarDados();
    }
    
    async function handleResolver(id, reviewId) {
        if (!window.confirm('Tem a certeza que quer resolver esta denúncia? A crítica ficará escondida.')) return;
        await resolverDenuncia(id, reviewId);
        carregarDados();
    }
    
    async function handleIgnorar(id) {
        if (!window.confirm('Tem a certeza que quer ignorar esta denúncia?')) return;
        await ignorarDenuncia(id);
        carregarDados();
    }
    
    const itensAtuais = abaAtiva === 'Filmes' ? filmes : abaAtiva === 'Séries' ? series : denuncias;
    
    return (
        <div className="admin-panel">
        <h1>Painel de Administrador</h1>
        
        <div className="admin-abas">
        {ABAS.map(aba => (
            <button
            key={aba}
            type="button"
            className={`admin-aba ${abaAtiva === aba ? 'active' : ''}`}
            onClick={() => setAbaAtiva(aba)}
            >
            {aba}
            {/* contador de pendentes */}
            {aba === 'Filmes' && filmes.length > 0 && (
                <span className="admin-badge">{filmes.length}</span>
            )}
            {aba === 'Séries' && series.length > 0 && (
                <span className="admin-badge">{series.length}</span>
            )}
            {aba === 'Denúncias' && denuncias.length > 0 && (
                <span className="admin-badge">{denuncias.length}</span>
            )}
            </button>
        ))}
        </div>
        
        <div className="admin-conteudo">
        {loading ? (
            <p>A carregar...</p>
        ) : itensAtuais.length === 0 ? (
            <p className="admin-vazio">Nenhum item pendente.</p>
        ) : (
            <>
            {abaAtiva !== 'Denúncias' && itensAtuais.map(item => (
                <div key={item.id} className="admin-card">
                <div className="admin-card-info">
                {item.imageurl && (
                    <img src={item.imageurl} alt={item.title} className="admin-card-img" />
                )}
                <div>
                <h3>{item.title}</h3>
                {item.genre && <p><strong>Género:</strong> {item.genre}</p>}
                {item.synopsis && <p><strong>Sinopse:</strong> {item.synopsis}</p>}
                {item.duration && <p><strong>Duração:</strong> {item.duration} min</p>}
                {item.episodes && <p><strong>Episódios:</strong> {item.episodes}</p>}
                </div>
                </div>
                <div className="admin-card-acoes">
                <button
                type="button"
                className="btn-aprovar"
                onClick={() => handleAprovar(item.id)}
                >
                Aprovar
                </button>
                <button
                type="button"
                className="btn-rejeitar"
                onClick={() => handleRejeitar(item.id)}
                >
                Rejeitar
                </button>
                </div>
                </div>
            ))}
            
            {abaAtiva === 'Denúncias' && itensAtuais.map(item => (
                <div key={item.id} className="admin-card">
                <div className="admin-card-info">
                <div>
                <p><strong>Denunciado por:</strong> {item.reporter_username ?? 'Desconhecido'}</p>
                <p><strong>Utilizador denunciado:</strong> {item.reviewed_username ?? 'Desconhecido'}</p>
                <p><strong>Motivo:</strong> {item.reason}</p>
                {item.description && <p><strong>Descrição:</strong> {item.description}</p>}
                {item.review_text && <p><strong>Crítica:</strong> {item.review_text}</p>}
                </div>
                </div>
                <div className="admin-card-acoes">
                <button
                type="button"
                className="btn-aprovar"
                onClick={() => handleResolver(item.id, item.reportedcontent)}
                >
                Resolver
                </button>
                <button
                type="button"
                className="btn-rejeitar"
                onClick={() => handleIgnorar(item.id)}
                >
                Ignorar
                </button>
                </div>
                </div>
            ))}
            </>
        )}
        </div>
        </div>
    );
}

export default AdminPanel;